// import 'package:debate_app/core/theme/color.dart';
// import 'package:debate_app/features/Debate/domain/entities/chat_entity.dart';
// import 'package:debate_app/features/Debate/presentation/bloc/debate_bloc.dart';
// import 'package:debate_app/features/Debate/presentation/widgets/chat_bubble_widget.dart';
// import 'package:debate_app/features/Debate/presentation/widgets/message_input_widget.dart';

// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// class ChatPage extends StatefulWidget {
//   final String topic;
//   final String role;
//   const ChatPage({super.key, required this.topic, required this.role});

//   @override
//   State<ChatPage> createState() => _ChatPageState();
// }

// class _ChatPageState extends State<ChatPage> {
//   final TextEditingController _textController = TextEditingController();
//   final ScrollController _scrollController = ScrollController();

//   @override
//   void dispose() {
//     _textController.dispose();
//     _scrollController.dispose();
//     super.dispose();
//   }

//   void _scrollToBottom() {
//     if (_scrollController.hasClients) {
//       _scrollController.animateTo(
//         _scrollController.position.maxScrollExtent,
//         duration: const Duration(milliseconds: 300),
//         curve: Curves.easeOut,
//       );
//     }
//   }

//   void _sendMessage() {
//     if (_textController.text.trim().isNotEmpty) {
//       context.read<DebateBloc>().add(
//         SendMessageEvent(_textController.text.trim()),
//       );
//       _textController.clear();
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColor.background,
//       appBar: AppBar(
//         title: Text("Session"),
//         foregroundColor: Colors.white,
//         centerTitle: true,
//         backgroundColor: Colors.transparent,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back_ios_new),
//           onPressed: () => Navigator.pop(context),
//         ),
//       ),
//       body: Column(
//         children: [
//           Expanded(
//             child: BlocConsumer<DebateBloc, DebateState>(
//               listener: (context, state) {
//                 if (state is DebatLoaded) {
//                   WidgetsBinding.instance.addPostFrameCallback(
//                     (_) => _scrollToBottom(),
//                   );
//                 } else if (state is DebateError) {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     SnackBar(
//                       content: Text(state.message),
//                       backgroundColor: Colors.red,
//                     ),
//                   );
//                 }
//               },
//               builder: (context, state) {
//                 if (state is DebateError) {
//                   return const Center(
//                     child: Text("Mulai debat dengan tekan Voice"),
//                   );
//                 }
//                 final messages = context.watch<DebateBloc>().messages;
//                 return ListView.builder(
//                   controller: _scrollController,
//                   padding: const EdgeInsets.symmetric(vertical: 8.0),
//                   itemCount: messages.length + (state is DebateLoading ? 1 : 0),
//                   itemBuilder: (context, index) {
//                     if (state is DebateLoading && index == messages.length) {
//                       return ChatBubbleWidget(
//                         message: ChatEntity(role: "assistant", content: "..."),
//                       );
//                     }

//                     return ChatBubbleWidget(message: messages[index]);
//                   },
//                 );
//               },
//             ),
//           ),
//         ],
//       ),
//       bottomNavigationBar: MessageInputWidget(
//         textController: _textController,
//         sendMessage: _sendMessage,
//       ),
//     );
//   }
// }
import 'package:debate_app/features/Debate/presentation/bloc/debate_bloc.dart';
import 'package:debate_app/features/Debate/presentation/widgets/chat_bubble_widget.dart';
import 'package:debate_app/features/Debate/presentation/widgets/message_input_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ChatPage extends StatelessWidget {
  final String topic;

  ChatPage({Key? key, required this.topic}) : super(key: key);
  final TextEditingController textEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(topic)),
      body: Column(
        children: [
          Expanded(
            child: BlocBuilder<DebateBloc, DebateState>(
              builder: (context, state) {
                if (state is DebateLoading) {
                  return const Center(child: CircularProgressIndicator());
                } else if (state is DebatLoaded) {
                  if (state.messages.isEmpty) {
                    return const Center(
                      child: Text("Belum ada pesan. Mulai debat sekarang!"),
                    );
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: state.messages.length,
                    itemBuilder: (context, index) {
                      final message = state.messages[index];
                      return ChatBubbleWidget(message: message);
                    },
                  );
                } else if (state is DebateError) {
                  return Center(child: Text("Error: ${state.message}"));
                }
                return const Center(
                  child: Text("Mulai debat dengan memilih peran Anda"),
                );
              },
            ),
          ),
          MessageInputWidget(
            sendMessage: () {
              if (textEditingController.text.trim().isNotEmpty) {
                context.read<DebateBloc>().add(
                  SendMessageEvent(textEditingController.text.trim()),
                );
                textEditingController.clear();
              }
            },
            textController: textEditingController,
          ),
        ],
      ),
    );
  }
}
