import 'package:debate_app/features/Debate/domain/entities/chat_entity.dart';
import 'package:debate_app/features/Debate/domain/usecases/create_session_usecase.dart';
import 'package:debate_app/features/Debate/domain/usecases/send_message_usecase.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'debate_event.dart';
part 'debate_state.dart';

class DebateBloc extends Bloc<DebateEvent, DebateState> {
  final SendmessageUsecase sendMessage;
  final CreateSessionUsecase createSession;
  int currentSessionId = 0;
  List<ChatEntity> messages = [];

  DebateBloc({required this.sendMessage, required this.createSession})
    : super(DebateInitial()) {
    on<SendMessageEvent>((event, emit) async {
      if (currentSessionId == 0) {
        emit(
          DebateError(
            message: "No active session. Please create a session first.",
          ),
        );
        return;
      }

      emit(DebateLoading());
      messages.add(
        ChatEntity(
          content: event.prompt,
          role: 'user',
          sessionId: currentSessionId,
        ),
      );

      try {
        final aiMessage = await sendMessage(
          prompt: event.prompt,
          sessionId: currentSessionId,
        );
        messages.add(aiMessage);
        emit(DebatLoaded(messages: List.from(messages)));
      } catch (e) {
        emit(DebateError(message: e.toString()));
      }
    });

    on<CreateSessionEvent>((event, emit) async {
      emit(DebateLoading());
      messages = []; // Clear previous messages

      try {
        final result = await createSession(
          prompt: event.prompt,
          topic: event.topic,
          role: event.role,
        );

        currentSessionId = result['session_id'];

        // Add user's initial message
        messages.add(
          ChatEntity(
            sessionId: currentSessionId,
            content: event.prompt,
            role: 'user',
          ),
        );

        // Add AI's initial response
        messages.add(
          ChatEntity(
            sessionId: currentSessionId,
            content: result['response'],
            role: 'ai',
          ),
        );

        emit(DebatLoaded(messages: List.from(messages)));
      } catch (e) {
        emit(DebateError(message: e.toString()));
      }
    });
  }
}

// import 'package:bloc/bloc.dart';
// import 'package:debate_app/features/Debate/domain/usecases/create_session_usecase.dart';
// import 'package:debate_app/shared/utils/logger.dart';
// import 'package:debate_app/features/Debate/domain/entities/chat_entity.dart';
// import 'package:debate_app/features/Debate/domain/usecases/send_message_usecase.dart';
// import 'package:equatable/equatable.dart';

// part 'debate_event.dart';
// part 'debate_state.dart';

// class DebateBloc extends Bloc<DebateEvent, DebateState> {
//   final SendmessageUsecase sendMessage;
//   final CreateSessionUsecase createSession;
//   int? currentSessionId;
//   List<ChatEntity> messages = [];

//   DebateBloc({required this.sendMessage, required this.createSession})
//     : super(DebateInitial()) {
//     on<SendMessageEvent>((event, emit) async {
//       emit(DebateLoading());
//       final userMessage = ChatEntity(
//         role: 'user',
//         content: event.prompt,
//         sessionId: currentSessionId,
//       );
//       messages.add(userMessage);

//       try {
//         final aiMessage = await sendMessage(
//           prompt: event.prompt,

//           // local storage null isFirst >
//           //  "prompt": "Saya setuju bahwa AI akan membantu manusia, bukan menggantikan mereka",
//           // "topic": "Apakah AI akan menggantikan pekerjaan manusia?",
//           // "pihak": "Pro",
//           // ls !null
//           // "prompt": "Namun, bukankah AI sudah mulai menggantikan pekerjaan di sektor manufaktur?",
//           // "sessionId": local storage
//           // sessionIDls = 1 dan topicls = A
//           // if (topicls == topic && sessionIDls == sessionId) => lanjut chat sebelumnya
//           sessionId: currentSessionId,
//         );
//         AppLogger.info("Prompt: ${event.prompt}");
//         AppLogger.info("AI Message session Id: ${aiMessage.sessionId}");
//         AppLogger.info("AI Message content: ${aiMessage.content}");
//         currentSessionId = aiMessage.sessionId;
//         AppLogger.info("Current Session ID: $currentSessionId");
//         messages.add(aiMessage);

//         emit(DebatLoaded(messages: List.from(messages)));
//       } catch (e) {
//         emit(DebateError(message: e.toString()));
//       }
//     });
//     on<CreateSessionEvent>((event, emit) async {
//       emit(DebateLoading());
//       try {
//         final newSession = await createSession(
//           prompt: event.prompt,
//           topic: event.topic,
//           role: event.role,
//         );
//         currentSessionId = newSession.sessionId;
//         messages.add(newSession);
//         AppLogger.info("Current Session ID: $currentSessionId");
//         emit(DebatLoaded(messages: List.from(messages)));
//       } catch (e) {
//         emit(DebateError(message: e.toString()));
//       }
//     });
//   }
// }
