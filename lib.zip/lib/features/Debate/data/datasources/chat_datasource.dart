import 'package:debate_app/core/config/api_config.dart';
import 'package:debate_app/shared/utils/logger.dart';
import 'package:dio/dio.dart';

abstract class ChatDatasource {
  Future<Map<String, dynamic>> sendMessage({
    required String prompt,
    int? sessionId,
    // String? topic,
    // String? role,
  });
  Future<Map<String, dynamic>> createSession({
    required String prompt,
    required String topic,
    required String role,
  });
}

class ChatDatasourceImpl implements ChatDatasource {
  final Dio dio;

  ChatDatasourceImpl({required this.dio});
  @override
  Future<Map<String, dynamic>> sendMessage({
    required String prompt,
    int? sessionId,
    // String? topic,
    // String? role,
  }) async {
    try {
      final apiUrl = ApiConfig.chatEndpoint;
      final Map<String, dynamic> data = {"prompt": prompt};

      // if (topic != null) {
      //   data['topic'] = topic;
      // }
      // if (role != null) {
      //   data['pihak'] = role;
      // }

      if (sessionId != null) {
        // current session
        data['sessionId'] = sessionId;
      }

      final response = await dio.post(
        apiUrl,
        data: data,
        options: Options(
          contentType: "application/json",
          headers: {'Accept': 'application/json'},
        ),
      );

      if (response.statusCode == 200) {
        if (response.data is Map<String, dynamic>) {
          return response.data;
        } else {
          throw Exception("Format Tidak sesuai");
        }
      } else {
        throw Exception("Gagal mengirim pesan: ${response.statusMessage}");
      }
    } catch (e) {
      AppLogger.error("Error dalam pengiriman pesan: $e");
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>> createSession({
    required String prompt,
    required String topic,
    required String role,
  }) async {
    try {
      final apiUrl = ApiConfig.chatEndpoint;
      final Map<String, dynamic> data = {
        "prompt": prompt,
        "topic": topic,
        "pihak": role,
      };

      final response = await dio.post(
        apiUrl,
        data: data,
        options: Options(
          contentType: "application/json",
          headers: {'Accept': 'application/json'},
        ),
      );

      if (response.statusCode == 200) {
        if (response.data is Map<String, dynamic>) {
          return response.data;
        } else {
          throw Exception("Format Tidak sesuai");
        }
      } else {
        throw Exception("Gagal mengirim pesan: ${response.statusMessage}");
      }
    } catch (e) {
      AppLogger.error("Error dalam pembuatan sesi: $e");
      rethrow;
    }
  }
}
