import 'package:flutter/material.dart';

class AppColor {
  static get background => Color(0xFF181828);
  static get accent => Color(0xFF262641);
  static get purpleLight => Color(0xFFBA8AD2);
}
